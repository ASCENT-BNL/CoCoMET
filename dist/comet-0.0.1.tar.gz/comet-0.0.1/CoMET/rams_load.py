#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 18:01:16 2024

@author: thahn
"""

# =============================================================================
# TODO Implement iris cube and xarray reading for RAMS model data
# =============================================================================
