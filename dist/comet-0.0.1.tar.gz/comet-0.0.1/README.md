# CoMET
Convective cloud Model Evaluation Toolkit.


## Acknowledgments
This project was supported in part by the U.S. Department of Energy, Office of Science,
Office of Workforce Development for Teachers and Scientists (WDTS) under the
Science Undergraduate Laboratory Internships Program (SULI) and by the Brookhaven National Laboratory (BNL), 
Environmental and Climate Sciences Department (ECSD) under the BNL Supplemental Undergraduate Research Program (SURP).